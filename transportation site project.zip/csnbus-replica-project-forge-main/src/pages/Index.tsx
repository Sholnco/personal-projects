
import { useEffect } from 'react';
import Layout from '@/components/layout/Layout';
import HeroSection from '@/components/home/HeroSection';
import ServicesSection from '@/components/home/ServicesSection';
import AboutSection from '@/components/home/AboutSection';
import ReservationSection from '@/components/home/ReservationSection';
import TestimonialsSection from '@/components/home/TestimonialsSection';
import AreasServedSection from '@/components/home/AreasServedSection';
import CorporateSection from '@/components/home/CorporateSection';
import ContactSection from '@/components/home/ContactSection';

const HomePage = () => {
  useEffect(() => {
    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const href = this.getAttribute('href');
        if (!href) return;
        
        const targetElement = document.querySelector(href);
        if (!targetElement) return;
        
        window.scrollTo({
          top: targetElement.getBoundingClientRect().top + window.pageYOffset - 100,
          behavior: 'smooth'
        });
      });
    });

    return () => {
      document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.removeEventListener('click', function () {});
      });
    };
  }, []);

  return (
    <Layout>
      <HeroSection />
      <ServicesSection />
      <AboutSection />
      <ReservationSection />
      <TestimonialsSection />
      <AreasServedSection />
      <CorporateSection />
      <ContactSection />
    </Layout>
  );
};

export default HomePage;
