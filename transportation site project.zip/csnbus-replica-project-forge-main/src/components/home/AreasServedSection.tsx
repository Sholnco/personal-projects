
import { MapPin } from 'lucide-react';

const areas = [
  {
    name: 'Downtown Charleston',
    description: 'Historic district with cobblestone streets and antebellum architecture.',
    image: 'https://images.unsplash.com/photo-1577601578926-23d074d2d4cc?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80'
  },
  {
    name: 'Mount Pleasant',
    description: 'Charming suburb across the Cooper River from Charleston.',
    image: 'https://images.unsplash.com/photo-1587871101136-227ba3a10bb0?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80'
  },
  {
    name: 'North Charleston',
    description: 'Commercial and industrial center with the airport and convention center.',
    image: 'https://images.unsplash.com/photo-1602969565463-c2c8380343da?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80'
  },
  {
    name: 'Isle of Palms',
    description: 'Beautiful beach destination with oceanfront properties.',
    image: 'https://images.unsplash.com/photo-1531168010535-2e8b3303d4ef?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80'
  },
  {
    name: 'Sullivan\'s Island',
    description: 'Relaxed beach community with a picturesque lighthouse.',
    image: 'https://images.unsplash.com/photo-1568402294069-8a758eef3b4d?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80'
  },
  {
    name: 'Folly Beach',
    description: 'Known for its surf spots, fishing pier, and laid-back vibe.',
    image: 'https://images.unsplash.com/photo-1544629942-4f9a562baed4?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80'
  },
  {
    name: 'Summerville',
    description: 'Charming town known for its flower gardens and historic homes.',
    image: 'https://images.unsplash.com/photo-1525897090696-01c70221f823?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80'
  },
  {
    name: 'Charleston International Airport',
    description: 'Main airport serving the Charleston metropolitan area.',
    image: 'https://images.unsplash.com/photo-1542296332-2e4473faf563?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80'
  }
];

const AreasServedSection = () => {
  return (
    <section id="areas" className="section-padding bg-gray-50">
      <div className="container-custom">
        <h2 className="section-heading">Areas Served</h2>
        <p className="text-center text-gray-600 max-w-3xl mx-auto mb-10">
          CSNBus provides transportation services throughout the Charleston 
          metropolitan area. Our service areas include:
        </p>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {areas.map((area, index) => (
            <div key={index} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
              <div className="h-40 overflow-hidden">
                <img 
                  src={area.image} 
                  alt={area.name} 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-4">
                <div className="flex items-start mb-2">
                  <MapPin className="text-csnblue mr-1 mt-1 flex-shrink-0" size={16} />
                  <h3 className="font-semibold">{area.name}</h3>
                </div>
                <p className="text-sm text-gray-600">{area.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default AreasServedSection;
