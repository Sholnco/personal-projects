
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';

const slides = [
  {
    image: 'https://images.unsplash.com/photo-1570125909232-eb263c188f7e?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80',
    title: 'Charleston\'s Premier Transportation Service',
    description: 'Reliable, comfortable, and affordable shuttle services throughout Charleston and surrounding areas.',
  },
  {
    image: 'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80',
    title: 'Airport Transfers Made Easy',
    description: 'Stress-free travel to and from Charleston International Airport with our professional shuttle service.',
  },
  {
    image: 'https://images.unsplash.com/photo-1679678691006-0ad24fecb769?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80',
    title: 'Corporate & Group Transportation',
    description: 'Customized transportation solutions for corporate events, weddings, and group outings.',
  },
];

const HeroSection = () => {
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev === slides.length - 1 ? 0 : prev + 1));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  return (
    <section className="relative h-screen">
      {/* Slides */}
      {slides.map((slide, index) => (
        <div
          key={index}
          className={`absolute inset-0 w-full h-full bg-cover bg-center slide-transition ${
            currentSlide === index ? 'opacity-100' : 'opacity-0'
          }`}
          style={{ backgroundImage: `url(${slide.image})` }}
        >
          <div className="hero-overlay"></div>
        </div>
      ))}

      {/* Hero Content */}
      <div className="relative z-20 h-full flex items-center">
        <div className="container-custom text-center text-white">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4 animate-fade-in">
            {slides[currentSlide].title}
          </h1>
          <p className="text-lg md:text-xl max-w-3xl mx-auto mb-8 animate-fade-in">
            {slides[currentSlide].description}
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in">
            <Button className="bg-csnblue hover:bg-csnblue-dark text-lg py-6 px-8">
              Book Now
            </Button>
            <Button variant="outline" className="border-white text-white hover:bg-white hover:text-csnblue text-lg py-6 px-8">
              Learn More
            </Button>
          </div>
        </div>
      </div>

      {/* Slide Indicators */}
      <div className="absolute bottom-8 left-0 right-0 z-20 flex justify-center space-x-3">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentSlide(index)}
            className={`w-3 h-3 rounded-full ${
              currentSlide === index ? 'bg-white' : 'bg-white bg-opacity-50'
            }`}
          ></button>
        ))}
      </div>
    </section>
  );
};

export default HeroSection;
