
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar } from '@/components/ui/calendar';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { CalendarIcon } from 'lucide-react';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

const ReservationSection = () => {
  const [date, setDate] = useState<Date>();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    serviceType: '',
    passengers: '',
    pickupLocation: '',
    dropoffLocation: '',
    specialRequests: '',
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Here we would handle form submission
    console.log({ ...formData, date });
    alert('Reservation submitted! We will contact you shortly to confirm your booking.');
  };

  return (
    <section id="reservation" className="section-padding bg-gray-50">
      <div className="container-custom">
        <h2 className="section-heading">Make a Reservation</h2>
        <div className="max-w-3xl mx-auto">
          <div className="bg-white rounded-lg shadow-md p-6 md:p-8">
            <form onSubmit={handleSubmit}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium mb-1">
                    Your Name
                  </label>
                  <Input
                    id="name"
                    name="name"
                    placeholder="Full Name"
                    value={formData.name}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                
                <div>
                  <label htmlFor="email" className="block text-sm font-medium mb-1">
                    Email Address
                  </label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    placeholder="your@email.com"
                    value={formData.email}
                    onChange={handleInputChange}
                    required
                  />
                </div>

                <div>
                  <label htmlFor="phone" className="block text-sm font-medium mb-1">
                    Phone Number
                  </label>
                  <Input
                    id="phone"
                    name="phone"
                    placeholder="(843) 123-4567"
                    value={formData.phone}
                    onChange={handleInputChange}
                    required
                  />
                </div>

                <div>
                  <label htmlFor="serviceType" className="block text-sm font-medium mb-1">
                    Service Type
                  </label>
                  <Select
                    onValueChange={(value) => handleSelectChange('serviceType', value)}
                  >
                    <SelectTrigger id="serviceType">
                      <SelectValue placeholder="Select service type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="airport">Airport Transfer</SelectItem>
                      <SelectItem value="corporate">Corporate Event</SelectItem>
                      <SelectItem value="wedding">Wedding</SelectItem>
                      <SelectItem value="group">Group Transportation</SelectItem>
                      <SelectItem value="tour">Tour / Sightseeing</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label htmlFor="passengers" className="block text-sm font-medium mb-1">
                    Number of Passengers
                  </label>
                  <Select
                    onValueChange={(value) => handleSelectChange('passengers', value)}
                  >
                    <SelectTrigger id="passengers">
                      <SelectValue placeholder="Select passengers" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1-5">1-5</SelectItem>
                      <SelectItem value="6-10">6-10</SelectItem>
                      <SelectItem value="11-15">11-15</SelectItem>
                      <SelectItem value="16-20">16-20</SelectItem>
                      <SelectItem value="20+">20+</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1">
                    Date of Service
                  </label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant={"outline"}
                        className={cn(
                          "w-full justify-start text-left font-normal",
                          !date && "text-muted-foreground"
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {date ? format(date, "PPP") : <span>Pick a date</span>}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={date}
                        onSelect={setDate}
                        initialFocus
                        className={cn("p-3 pointer-events-auto")}
                      />
                    </PopoverContent>
                  </Popover>
                </div>

                <div>
                  <label htmlFor="pickupLocation" className="block text-sm font-medium mb-1">
                    Pickup Location
                  </label>
                  <Input
                    id="pickupLocation"
                    name="pickupLocation"
                    placeholder="Address"
                    value={formData.pickupLocation}
                    onChange={handleInputChange}
                    required
                  />
                </div>

                <div>
                  <label htmlFor="dropoffLocation" className="block text-sm font-medium mb-1">
                    Drop-off Location
                  </label>
                  <Input
                    id="dropoffLocation"
                    name="dropoffLocation"
                    placeholder="Address"
                    value={formData.dropoffLocation}
                    onChange={handleInputChange}
                    required
                  />
                </div>
              </div>

              <div className="mb-6">
                <label htmlFor="specialRequests" className="block text-sm font-medium mb-1">
                  Special Requests
                </label>
                <Textarea
                  id="specialRequests"
                  name="specialRequests"
                  placeholder="Any special requirements or additional information"
                  rows={4}
                  value={formData.specialRequests}
                  onChange={handleInputChange}
                />
              </div>

              <Button
                type="submit"
                className="w-full bg-csnblue hover:bg-csnblue-dark"
              >
                Submit Reservation
              </Button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ReservationSection;
