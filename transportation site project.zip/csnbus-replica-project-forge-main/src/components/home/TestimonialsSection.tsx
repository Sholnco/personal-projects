
import { useState } from 'react';
import { ChevronLeft, ChevronRight, Star } from 'lucide-react';

interface Testimonial {
  id: number;
  name: string;
  role: string;
  quote: string;
  rating: number;
  image: string;
}

const testimonials: Testimonial[] = [
  {
    id: 1,
    name: 'Sarah Johnson',
    role: 'Business Traveler',
    quote: 'I use CSNBus for all my airport transfers in Charleston. Always on time, clean vehicles, and professional drivers. Highly recommended!',
    rating: 5,
    image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=150&q=80'
  },
  {
    id: 2,
    name: 'Michael Thompson',
    role: 'Wedding Planner',
    quote: 'CSNBus provided exceptional service for our wedding guests. The drivers were courteous, the vehicles were immaculate, and everything went smoothly.',
    rating: 5,
    image: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-1.2.1&auto=format&fit=crop&w=150&q=80'
  },
  {
    id: 3,
    name: 'Jennifer Davis',
    role: 'Tour Group Coordinator',
    quote: 'Our group tour of Charleston was enhanced by the knowledgeable drivers from CSNBus. They were flexible with our schedule and provided great local insights.',
    rating: 4,
    image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-1.2.1&auto=format&fit=crop&w=150&q=80'
  },
];

const TestimonialsSection = () => {
  const [activeIndex, setActiveIndex] = useState(0);

  const goToNext = () => {
    setActiveIndex((prev) => (prev === testimonials.length - 1 ? 0 : prev + 1));
  };

  const goToPrev = () => {
    setActiveIndex((prev) => (prev === 0 ? testimonials.length - 1 : prev - 1));
  };

  const renderStars = (rating: number) => {
    return Array(5)
      .fill(0)
      .map((_, i) => (
        <Star
          key={i}
          className={`w-4 h-4 ${i < rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`}
        />
      ));
  };

  return (
    <section className="section-padding bg-white">
      <div className="container-custom">
        <h2 className="section-heading">What Our Clients Say</h2>
        
        <div className="max-w-4xl mx-auto">
          <div className="bg-gray-50 rounded-lg shadow-md p-8 md:p-10 relative">
            <button
              onClick={goToPrev}
              className="absolute left-2 md:left-4 top-1/2 -translate-y-1/2 bg-white rounded-full p-2 shadow-md hover:bg-gray-100 transition-colors"
              aria-label="Previous testimonial"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            
            <div className="text-center">
              <div className="h-20 w-20 mx-auto mb-4 overflow-hidden rounded-full">
                <img
                  src={testimonials[activeIndex].image}
                  alt={testimonials[activeIndex].name}
                  className="object-cover w-full h-full"
                />
              </div>
              
              <div className="flex justify-center mb-3">
                {renderStars(testimonials[activeIndex].rating)}
              </div>
              
              <blockquote className="text-lg italic mb-6">
                "{testimonials[activeIndex].quote}"
              </blockquote>
              
              <div>
                <p className="font-semibold">{testimonials[activeIndex].name}</p>
                <p className="text-sm text-gray-500">{testimonials[activeIndex].role}</p>
              </div>
            </div>
            
            <button
              onClick={goToNext}
              className="absolute right-2 md:right-4 top-1/2 -translate-y-1/2 bg-white rounded-full p-2 shadow-md hover:bg-gray-100 transition-colors"
              aria-label="Next testimonial"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
          
          {/* Testimonial Indicators */}
          <div className="flex justify-center mt-6 space-x-2">
            {testimonials.map((_, index) => (
              <button
                key={index}
                onClick={() => setActiveIndex(index)}
                className={`w-2.5 h-2.5 rounded-full transition-colors ${
                  activeIndex === index ? 'bg-csnblue' : 'bg-gray-300'
                }`}
                aria-label={`Go to testimonial ${index + 1}`}
              ></button>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
