
import { 
  Plane, 
  Users, 
  Building, 
  GraduationCap, 
  Heart, 
  Map
} from 'lucide-react';

interface ServiceCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const ServiceCard: React.FC<ServiceCardProps> = ({ icon, title, description }) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 transition-transform hover:-translate-y-1">
      <div className="text-csnblue mb-4 flex justify-center">
        {icon}
      </div>
      <h3 className="text-xl font-semibold mb-2 text-center">{title}</h3>
      <p className="text-gray-600 text-center">{description}</p>
    </div>
  );
};

const services = [
  {
    icon: <Plane size={36} />,
    title: 'Airport Transfers',
    description: 'Reliable transportation to and from Charleston International Airport.'
  },
  {
    icon: <Users size={36} />,
    title: 'Group Transportation',
    description: 'Comfortable shuttle services for groups of all sizes.'
  },
  {
    icon: <Building size={36} />,
    title: 'Corporate Events',
    description: 'Professional transportation solutions for business events.'
  },
  {
    icon: <GraduationCap size={36} />,
    title: 'School Events',
    description: 'Safe transportation for school trips, sporting events, and more.'
  },
  {
    icon: <Heart size={36} />,
    title: 'Wedding Shuttles',
    description: 'Elegant transportation for your special day.'
  },
  {
    icon: <Map size={36} />,
    title: 'Tours & Sightseeing',
    description: 'Explore Charleston with our guided transportation services.'
  }
];

const ServicesSection = () => {
  return (
    <section id="services" className="section-padding bg-gray-50">
      <div className="container-custom">
        <h2 className="section-heading">Our Services</h2>
        <p className="text-center text-gray-600 max-w-3xl mx-auto mb-10">
          CSNBus provides a wide range of transportation services in Charleston 
          and surrounding areas. Our professional drivers and comfortable vehicles 
          ensure a pleasant journey every time.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <ServiceCard 
              key={index}
              icon={service.icon}
              title={service.title} 
              description={service.description}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
