
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Phone, Mail, MapPin, Clock } from 'lucide-react';

const ContactSection = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: '',
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Here we would handle form submission
    console.log(formData);
    alert('Message sent! We will get back to you shortly.');
  };

  const contactInfo = [
    {
      icon: <Phone size={20} />,
      label: 'Phone',
      value: '843-501-1819',
      href: 'tel:8435011819',
    },
    {
      icon: <Mail size={20} />,
      label: 'Email',
      value: 'info@csnbus.com',
      href: 'mailto:info@csnbus.com',
    },
    {
      icon: <MapPin size={20} />,
      label: 'Address',
      value: 'Charleston, South Carolina',
      href: 'https://maps.google.com/?q=Charleston,SC',
    },
    {
      icon: <Clock size={20} />,
      label: 'Business Hours',
      value: 'Mon-Sun: 24/7',
      href: null,
    },
  ];

  return (
    <section id="contact" className="section-padding">
      <div className="container-custom">
        <h2 className="section-heading">Contact Us</h2>
        <p className="text-center text-gray-600 max-w-3xl mx-auto mb-12">
          Have questions about our services? Need to make a special request? Our team is ready to assist you.
          Contact us using the form below or reach out directly through our contact information.
        </p>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-xl font-semibold mb-6">Send Us a Message</h3>
            
            <form onSubmit={handleSubmit}>
              <div className="space-y-4">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium mb-1">
                    Your Name
                  </label>
                  <Input
                    id="name"
                    name="name"
                    placeholder="Full Name"
                    value={formData.name}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                
                <div>
                  <label htmlFor="email" className="block text-sm font-medium mb-1">
                    Email Address
                  </label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    placeholder="your@email.com"
                    value={formData.email}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                
                <div>
                  <label htmlFor="phone" className="block text-sm font-medium mb-1">
                    Phone Number
                  </label>
                  <Input
                    id="phone"
                    name="phone"
                    placeholder="(843) 123-4567"
                    value={formData.phone}
                    onChange={handleInputChange}
                  />
                </div>
                
                <div>
                  <label htmlFor="message" className="block text-sm font-medium mb-1">
                    Message
                  </label>
                  <Textarea
                    id="message"
                    name="message"
                    placeholder="How can we help you?"
                    rows={4}
                    value={formData.message}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                
                <Button
                  type="submit"
                  className="w-full bg-csnblue hover:bg-csnblue-dark"
                >
                  Send Message
                </Button>
              </div>
            </form>
          </div>
          
          <div>
            <div className="bg-gray-50 rounded-lg shadow-md p-6 mb-8">
              <h3 className="text-xl font-semibold mb-6">Contact Information</h3>
              
              <div className="space-y-6">
                {contactInfo.map((item, index) => (
                  <div key={index} className="flex">
                    <div className="bg-csnblue text-white p-3 rounded-full mr-4">
                      {item.icon}
                    </div>
                    <div>
                      <h4 className="font-medium">{item.label}</h4>
                      {item.href ? (
                        <a 
                          href={item.href} 
                          className="text-csnblue hover:underline"
                          target={item.label === 'Address' ? '_blank' : undefined}
                          rel={item.label === 'Address' ? 'noopener noreferrer' : undefined}
                        >
                          {item.value}
                        </a>
                      ) : (
                        <p>{item.value}</p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            {/* Google Maps Embed */}
            <div className="rounded-lg shadow-md overflow-hidden h-72">
              <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d106387.43083898284!2d-79.99754087555152!3d32.7764749949246!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x88fe7a42dca82477%3A0x35faf7e0aee1ec6b!2sCharleston%2C%20SC!5e0!3m2!1sen!2sus!4v1695864651195!5m2!1sen!2sus"
                width="100%" 
                height="100%" 
                style={{ border: 0 }} 
                allowFullScreen 
                loading="lazy" 
                referrerPolicy="no-referrer-when-downgrade"
                title="CSNBus Location"
              ></iframe>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
