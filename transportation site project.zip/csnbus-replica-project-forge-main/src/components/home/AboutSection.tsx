
import { Button } from '@/components/ui/button';
import { Check } from 'lucide-react';

const AboutSection = () => {
  const features = [
    'Professional and courteous drivers',
    'Modern and well-maintained vehicles',
    'Punctual and reliable service',
    'Competitive pricing',
    'Customizable transportation solutions',
    'Local knowledge of Charleston area',
  ];

  return (
    <section id="about" className="section-padding">
      <div className="container-custom">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="order-2 lg:order-1">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">About CSNBus</h2>
            <p className="text-gray-600 mb-6">
              Since our founding, CSNBus has been committed to providing exceptional 
              transportation services throughout Charleston and the surrounding areas. 
              Our mission is to deliver safe, reliable, and comfortable transportation 
              experiences that exceed our customers' expectations.
            </p>
            <p className="text-gray-600 mb-6">
              With a team of professional drivers and a fleet of well-maintained vehicles, 
              we have become Charleston's trusted choice for airport transfers, corporate 
              events, group outings, and more. We take pride in our punctuality, attention 
              to detail, and commitment to customer satisfaction.
            </p>
            
            <ul className="mb-8 space-y-3">
              {features.map((feature, index) => (
                <li key={index} className="flex items-center">
                  <Check className="text-csnblue mr-2" size={18} />
                  <span>{feature}</span>
                </li>
              ))}
            </ul>
            
            <Button className="bg-csnblue hover:bg-csnblue-dark">
              Learn More About Us
            </Button>
          </div>
          
          <div className="order-1 lg:order-2">
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80" 
                alt="CSNBus Service" 
                className="rounded-lg shadow-lg w-full h-auto object-cover"
              />
              <div className="absolute -bottom-6 -right-6 bg-csnblue text-white p-4 rounded-lg shadow-lg hidden md:block">
                <p className="text-xl font-bold">10+ Years</p>
                <p className="text-sm">of Excellence</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
