
import { Button } from '@/components/ui/button';
import { Check } from 'lucide-react';

const CorporateSection = () => {
  const features = [
    'Dedicated corporate accounts',
    'Customized billing options',
    'Professional, uniformed drivers',
    'Modern, well-maintained fleet',
    'Airport meet & greet service',
    '24/7 dispatch and support',
  ];

  return (
    <section id="corporate" className="section-padding bg-csnblue text-white">
      <div className="container-custom">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Corporate Transportation Solutions</h2>
            <p className="mb-6">
              CSNBus offers premium transportation services tailored to meet the 
              needs of businesses in Charleston. Whether you need executive transfers, 
              airport pickups for clients, or group transportation for corporate events, 
              we provide reliable, professional service.
            </p>
            
            <div className="mb-8">
              <h3 className="text-xl font-semibold mb-4">Our Corporate Services Include:</h3>
              <ul className="space-y-3">
                {features.map((feature, index) => (
                  <li key={index} className="flex items-center">
                    <Check className="mr-2" size={18} />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Button className="bg-white text-csnblue hover:bg-gray-100">
                Set Up Corporate Account
              </Button>
              <Button variant="outline" className="text-white border-white hover:bg-csnblue-dark">
                Learn More
              </Button>
            </div>
          </div>
          
          <div className="relative">
            <img 
              src="https://images.unsplash.com/photo-1529400971008-f566de0e6dfc?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80" 
              alt="Corporate Transportation" 
              className="rounded-lg shadow-lg w-full h-auto object-cover"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default CorporateSection;
