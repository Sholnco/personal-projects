
import { Link } from 'react-router-dom';
import { Phone, Mail, MapPin, Facebook, Instagram, Twitter } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-csnnavy text-white pt-12 pb-6">
      <div className="container-custom">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <h3 className="text-xl font-semibold mb-4">CSNBus</h3>
            <p className="mb-4">Your premier transportation service in Charleston, SC. Reliable, comfortable, and professional.</p>
            <div className="flex space-x-4">
              <a href="https://facebook.com" className="hover:text-gray-300" aria-label="Facebook">
                <Facebook size={20} />
              </a>
              <a href="https://instagram.com" className="hover:text-gray-300" aria-label="Instagram">
                <Instagram size={20} />
              </a>
              <a href="https://twitter.com" className="hover:text-gray-300" aria-label="Twitter">
                <Twitter size={20} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-xl font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><a href="/" className="hover:text-gray-300">Home</a></li>
              <li><a href="#services" className="hover:text-gray-300">Services</a></li>
              <li><a href="#about" className="hover:text-gray-300">About Us</a></li>
              <li><a href="#reservation" className="hover:text-gray-300">Reservation</a></li>
              <li><a href="#areas" className="hover:text-gray-300">Areas Served</a></li>
              <li><a href="#contact" className="hover:text-gray-300">Contact</a></li>
            </ul>
          </div>

          {/* Service Areas */}
          <div>
            <h3 className="text-xl font-semibold mb-4">Service Areas</h3>
            <ul className="space-y-2">
              <li>Charleston</li>
              <li>Mount Pleasant</li>
              <li>North Charleston</li>
              <li>Summerville</li>
              <li>Goose Creek</li>
              <li>Isle of Palms</li>
              <li>Sullivan's Island</li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-xl font-semibold mb-4">Contact Us</h3>
            <ul className="space-y-3">
              <li className="flex items-center">
                <Phone size={16} className="mr-3" />
                <span>843-501-1819</span>
              </li>
              <li className="flex items-center">
                <Mail size={16} className="mr-3" />
                <span>info@csnbus.com</span>
              </li>
              <li className="flex items-start">
                <MapPin size={16} className="mr-3 mt-1" />
                <span>Charleston, South Carolina</span>
              </li>
            </ul>
          </div>
        </div>

        <hr className="border-gray-700 my-8" />

        <div className="flex flex-col md:flex-row items-center justify-between text-sm">
          <p>&copy; {new Date().getFullYear()} CSNBus. All rights reserved.</p>
          <div className="mt-4 md:mt-0 flex space-x-6">
            <Link to="/privacy-policy" className="hover:text-gray-300">Privacy Policy</Link>
            <Link to="/terms-of-service" className="hover:text-gray-300">Terms of Service</Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
