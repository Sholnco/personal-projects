
import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Menu, Phone, MapPin } from 'lucide-react';

interface NavLink {
  text: string;
  href: string;
}

const navLinks: NavLink[] = [
  { text: 'Home', href: '/' },
  { text: 'Services', href: '#services' },
  { text: 'About Us', href: '#about' },
  { text: 'Reservation', href: '#reservation' },
  { text: 'Areas Served', href: '#areas' },
  { text: 'Corporate', href: '#corporate' },
  { text: 'Contact', href: '#contact' },
];

const Header = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  useEffect(() => {
    const handleScroll = () => {
      const offset = window.scrollY;
      if (offset > 50) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <header
      className={`w-full fixed top-0 left-0 z-50 transition-all duration-300 ${
        scrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'
      }`}
    >
      <div className="container-custom mx-auto">
        <div className="flex flex-wrap items-center justify-between">
          <div className="flex items-center">
            <Link to="/" className="flex items-center">
              <img
                src="/logo.png"
                alt="CSNBus Logo"
                className="h-10 md:h-12"
                onError={(e) => {
                  e.currentTarget.src = "https://via.placeholder.com/150x50?text=CSNBus";
                }}
              />
            </Link>
          </div>

          {/* Contact Info (Desktop) */}
          <div className="hidden lg:flex items-center gap-6">
            <div className="flex items-center text-sm">
              <Phone size={16} className="mr-2 text-csnblue" />
              <span className="font-semibold">843-501-1819</span>
            </div>
            <div className="flex items-center text-sm">
              <MapPin size={16} className="mr-2 text-csnblue" />
              <span>Charleston, SC</span>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex">
            <ul className="flex space-x-6 items-center">
              {navLinks.map((link) => (
                <li key={link.text}>
                  <a 
                    href={link.href}
                    className="text-sm font-medium transition-colors hover:text-csnblue"
                  >
                    {link.text}
                  </a>
                </li>
              ))}
              <li>
                <Button className="bg-csnblue hover:bg-csnblue-dark">Book Now</Button>
              </li>
            </ul>
          </nav>

          {/* Mobile Menu Button */}
          <button
            className="lg:hidden p-2 rounded-md text-gray-700"
            onClick={toggleMobileMenu}
          >
            <Menu size={24} />
          </button>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <nav className="lg:hidden mt-4 py-2">
            <ul className="flex flex-col space-y-3">
              {navLinks.map((link) => (
                <li key={link.text}>
                  <a
                    href={link.href}
                    className="block text-sm font-medium py-2 hover:text-csnblue"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    {link.text}
                  </a>
                </li>
              ))}
              <li className="pt-2">
                <Button className="w-full bg-csnblue hover:bg-csnblue-dark">Book Now</Button>
              </li>
              <li className="flex items-center text-sm py-2">
                <Phone size={16} className="mr-2 text-csnblue" />
                <span className="font-semibold">843-501-1819</span>
              </li>
            </ul>
          </nav>
        )}
      </div>
    </header>
  );
};

export default Header;
