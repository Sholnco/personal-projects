
import { Button } from "@/components/ui/button";

const Hero = () => {
  return (
    <section className="min-h-screen flex items-center pt-20 pb-16 bg-gradient-to-br from-white to-motech-light-purple/20">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-8 items-center">
          <div className="order-2 md:order-1 animate-fade-in">
            <h1 className="text-4xl lg:text-5xl xl:text-6xl font-bold mb-6 leading-tight">
              <span className="text-motech-purple">Innovative</span> Tech Solutions for
              <br />
              Your Business Growth
            </h1>
            <p className="text-lg lg:text-xl text-gray-600 mb-8">
              We deliver cutting-edge technology solutions that transform businesses
              and drive sustainable growth in the digital era.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button className="bg-motech-purple hover:bg-motech-dark-purple text-white px-8 py-6 rounded-lg text-lg">
                Get Started
              </Button>
              <Button variant="outline" className="border-motech-purple text-motech-purple hover:bg-motech-light-purple px-8 py-6 rounded-lg text-lg">
                Learn More
              </Button>
            </div>
            <div className="mt-10 flex flex-wrap gap-6 items-center">
              <p className="text-gray-500 font-medium">Trusted by:</p>
              <div className="flex flex-wrap gap-8">
                <div className="w-24 h-8 bg-gray-200 rounded-md flex items-center justify-center">
                  <span className="text-gray-500 text-sm font-medium">COMPANY</span>
                </div>
                <div className="w-24 h-8 bg-gray-200 rounded-md flex items-center justify-center">
                  <span className="text-gray-500 text-sm font-medium">COMPANY</span>
                </div>
                <div className="w-24 h-8 bg-gray-200 rounded-md flex items-center justify-center">
                  <span className="text-gray-500 text-sm font-medium">COMPANY</span>
                </div>
              </div>
            </div>
          </div>
          <div className="order-1 md:order-2 animate-fade-in">
            <div className="rounded-2xl overflow-hidden shadow-2xl bg-gradient-to-br from-motech-purple to-motech-dark-purple p-1">
              <div className="bg-white rounded-xl overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1488590528505-98d2b5aba04b?auto=format&fit=crop&w=800&q=80" 
                  alt="Technology visualization" 
                  className="w-full h-auto object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
