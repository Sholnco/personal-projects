
import { Code, Server, Database, Layout, ArrowRight } from "lucide-react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const services = [
  {
    title: "Web Development",
    description: "Custom web applications and responsive websites built with modern frameworks",
    icon: <Layout className="h-12 w-12 text-motech-purple" />,
    link: "#"
  },
  {
    title: "App Development",
    description: "Native and cross-platform mobile applications for iOS and Android",
    icon: <Code className="h-12 w-12 text-motech-purple" />,
    link: "#"
  },
  {
    title: "Cloud Services",
    description: "Scalable cloud infrastructure, migration, and DevOps solutions",
    icon: <Server className="h-12 w-12 text-motech-purple" />,
    link: "#"
  },
  {
    title: "Data Analytics",
    description: "Big data processing, visualization, and business intelligence",
    icon: <Database className="h-12 w-12 text-motech-purple" />,
    link: "#"
  }
];

const Services = () => {
  return (
    <section id="services" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Services</h2>
          <div className="h-1 w-20 bg-motech-purple mx-auto mb-6"></div>
          <p className="text-lg text-gray-600">
            We offer comprehensive technology solutions tailored to your specific business needs
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <Card key={index} className="reveal border border-gray-100 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
              <CardHeader>
                <div className="mb-4">{service.icon}</div>
                <CardTitle className="text-xl font-bold">{service.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-gray-600">
                  {service.description}
                </CardDescription>
              </CardContent>
              <CardFooter>
                <a 
                  href={service.link}
                  className="text-motech-purple hover:text-motech-dark-purple font-medium flex items-center gap-1 group"
                >
                  Learn more
                  <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
                </a>
              </CardFooter>
            </Card>
          ))}
        </div>
        
        <div className="mt-16 text-center">
          <Button className="bg-motech-purple hover:bg-motech-dark-purple text-white px-8 py-6 rounded-lg text-lg">
            View All Services
          </Button>
        </div>
      </div>
    </section>
  );
};

export default Services;
