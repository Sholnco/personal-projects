
import { Facebook, Twitter, Instagram, Linkedin, Mail } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-motech-dark-bg text-white">
      <div className="container mx-auto px-4 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <h3 className="text-2xl font-bold mb-6">MoTech</h3>
            <p className="mb-6 text-gray-300">
              Innovative technology solutions for businesses seeking growth and digital transformation.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="bg-motech-purple/20 p-2 rounded-full hover:bg-motech-purple transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="bg-motech-purple/20 p-2 rounded-full hover:bg-motech-purple transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="bg-motech-purple/20 p-2 rounded-full hover:bg-motech-purple transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="bg-motech-purple/20 p-2 rounded-full hover:bg-motech-purple transition-colors">
                <Linkedin className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-xl font-bold mb-6">Services</h3>
            <ul className="space-y-3">
              <li><a href="#" className="text-gray-300 hover:text-white">Web Development</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white">App Development</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white">Cloud Services</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white">Data Analytics</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white">UI/UX Design</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white">IT Consulting</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-xl font-bold mb-6">Company</h3>
            <ul className="space-y-3">
              <li><a href="#about" className="text-gray-300 hover:text-white">About Us</a></li>
              <li><a href="#work" className="text-gray-300 hover:text-white">Our Work</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white">Careers</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white">Blog</a></li>
              <li><a href="#contact" className="text-gray-300 hover:text-white">Contact</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-xl font-bold mb-6">Newsletter</h3>
            <p className="mb-4 text-gray-300">
              Subscribe to our newsletter to receive updates and insights.
            </p>
            <form className="flex">
              <input
                type="email"
                placeholder="Your email"
                className="px-4 py-2 rounded-l-lg w-full bg-gray-700 border-0 focus:ring-2 focus:ring-motech-purple"
              />
              <button
                type="submit"
                className="bg-motech-purple hover:bg-motech-dark-purple p-2 rounded-r-lg"
              >
                <Mail className="h-5 w-5" />
              </button>
            </form>
          </div>
        </div>
        
        <div className="border-t border-gray-700 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p>&copy; {new Date().getFullYear()} MoTech. All rights reserved.</p>
          <div className="mt-4 md:mt-0">
            <ul className="flex space-x-6">
              <li><a href="#" className="text-gray-300 hover:text-white text-sm">Privacy Policy</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white text-sm">Terms of Service</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white text-sm">Cookie Policy</a></li>
            </ul>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
