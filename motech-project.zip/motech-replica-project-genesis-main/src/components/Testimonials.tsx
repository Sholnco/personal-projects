
import { useState } from "react";
import { ChevronLeft, ChevronRight, Quote } from "lucide-react";

const testimonials = [
  {
    id: 1,
    quote: "MoTech transformed our business with their innovative solutions. Their team understood our requirements perfectly and delivered beyond our expectations.",
    author: "Sarah Johnson",
    position: "CEO, TechStart Inc.",
    avatar: "https://randomuser.me/api/portraits/women/1.jpg"
  },
  {
    id: 2,
    quote: "Working with MoTech was a game-changer for our company. Their expertise in cloud solutions helped us scale our operations efficiently.",
    author: "Michael Chen",
    position: "CTO, GrowthWave",
    avatar: "https://randomuser.me/api/portraits/men/2.jpg"
  },
  {
    id: 3,
    quote: "The mobile application developed by MoTech increased our customer engagement by 200%. Their attention to detail and user experience is exceptional.",
    author: "Emily Rodriguez",
    position: "Marketing Director, NexGen",
    avatar: "https://randomuser.me/api/portraits/women/3.jpg"
  }
];

const Testimonials = () => {
  const [activeIndex, setActiveIndex] = useState(0);

  const nextTestimonial = () => {
    setActiveIndex((prevIndex) => (prevIndex + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setActiveIndex((prevIndex) => (prevIndex - 1 + testimonials.length) % testimonials.length);
  };

  return (
    <section id="testimonials" className="py-20 bg-motech-purple">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-white">What Our Clients Say</h2>
          <div className="h-1 w-20 bg-white mx-auto mb-6"></div>
        </div>
        
        <div className="max-w-4xl mx-auto relative">
          <div className="absolute -top-10 left-0 opacity-30">
            <Quote className="h-24 w-24 text-white" />
          </div>
          
          <div className="bg-white rounded-xl shadow-xl p-8 md:p-12 relative z-10">
            <div className="flex flex-col items-center text-center">
              <p className="text-lg md:text-xl leading-relaxed mb-8">
                {testimonials[activeIndex].quote}
              </p>
              <div className="w-16 h-16 rounded-full overflow-hidden mb-4">
                <img 
                  src={testimonials[activeIndex].avatar} 
                  alt={testimonials[activeIndex].author}
                  className="w-full h-full object-cover" 
                />
              </div>
              <h4 className="text-xl font-bold">{testimonials[activeIndex].author}</h4>
              <p className="text-gray-500">{testimonials[activeIndex].position}</p>
            </div>
          </div>
          
          <div className="mt-10 flex justify-center gap-4">
            <button 
              onClick={prevTestimonial}
              className="w-12 h-12 rounded-full bg-white text-motech-purple flex items-center justify-center hover:bg-gray-100"
              aria-label="Previous testimonial"
            >
              <ChevronLeft className="h-6 w-6" />
            </button>
            <div className="flex gap-2 items-center">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setActiveIndex(index)}
                  className={`w-3 h-3 rounded-full transition-all ${
                    activeIndex === index ? "bg-white scale-125" : "bg-white/50"
                  }`}
                  aria-label={`Go to testimonial ${index + 1}`}
                ></button>
              ))}
            </div>
            <button 
              onClick={nextTestimonial}
              className="w-12 h-12 rounded-full bg-white text-motech-purple flex items-center justify-center hover:bg-gray-100"
              aria-label="Next testimonial"
            >
              <ChevronRight className="h-6 w-6" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
