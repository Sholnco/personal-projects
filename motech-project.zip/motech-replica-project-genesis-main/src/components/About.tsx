
import { CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

const stats = [
  { value: "10+", label: "Years of Experience" },
  { value: "200+", label: "Projects Completed" },
  { value: "50+", label: "Team Members" },
  { value: "95%", label: "Client Satisfaction" }
];

const About = () => {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="reveal">
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?auto=format&fit=crop&w=800&q=80"
                alt="Our team at work"
                className="rounded-lg shadow-xl"
              />
              <div className="absolute -bottom-10 -right-10 bg-motech-purple rounded-lg p-6 shadow-xl">
                <div className="grid grid-cols-2 gap-6 text-white">
                  {stats.map((stat, index) => (
                    <div key={index} className="text-center">
                      <div className="text-3xl font-bold">{stat.value}</div>
                      <div className="text-sm">{stat.label}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
          
          <div className="reveal">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">About MoTech</h2>
            <div className="h-1 w-20 bg-motech-purple mb-6"></div>
            <p className="text-lg text-gray-600 mb-6">
              MoTech is a leading technology solutions provider founded in 2010. We specialize in delivering innovative digital solutions that help businesses thrive in today's competitive landscape.
            </p>
            <p className="text-lg text-gray-600 mb-8">
              Our team of expert developers, designers, and consultants work together to create tailored solutions that meet the unique needs of each client.
            </p>
            
            <div className="grid sm:grid-cols-2 gap-4 mb-8">
              <div className="flex items-start gap-2">
                <CheckCircle className="h-6 w-6 text-motech-purple flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-bold">Innovation First</h3>
                  <p className="text-gray-600">We embrace cutting-edge technologies</p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle className="h-6 w-6 text-motech-purple flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-bold">Client-Focused</h3>
                  <p className="text-gray-600">Your success is our priority</p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle className="h-6 w-6 text-motech-purple flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-bold">Quality Driven</h3>
                  <p className="text-gray-600">We deliver excellence in every project</p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle className="h-6 w-6 text-motech-purple flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-bold">End-to-End Solutions</h3>
                  <p className="text-gray-600">From concept to deployment</p>
                </div>
              </div>
            </div>
            
            <Button className="bg-motech-purple hover:bg-motech-dark-purple text-white">
              Learn More About Us
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
