
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Menu } from "lucide-react";

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? "bg-white shadow-md py-3" : "bg-transparent py-5"
      }`}
    >
      <div className="container mx-auto px-4 flex justify-between items-center">
        <a href="#" className="flex items-center">
          <span className="text-2xl font-bold text-motech-purple">MoTech</span>
        </a>

        <nav className="hidden md:flex items-center space-x-8">
          <a href="#services" className="text-gray-800 hover:text-motech-purple font-medium">
            Services
          </a>
          <a href="#work" className="text-gray-800 hover:text-motech-purple font-medium">
            Our Work
          </a>
          <a href="#about" className="text-gray-800 hover:text-motech-purple font-medium">
            About
          </a>
          <a href="#testimonials" className="text-gray-800 hover:text-motech-purple font-medium">
            Testimonials
          </a>
          <Button className="bg-motech-purple hover:bg-motech-dark-purple text-white">
            Contact Us
          </Button>
        </nav>

        <button className="md:hidden" onClick={toggleMobileMenu}>
          <Menu className="h-6 w-6 text-gray-800" />
        </button>
      </div>

      {/* Mobile menu */}
      <div
        className={`md:hidden absolute top-full left-0 right-0 bg-white shadow-md transition-transform duration-300 ${
          mobileMenuOpen ? "translate-y-0" : "-translate-y-full"
        }`}
      >
        <div className="container mx-auto px-4 py-4 flex flex-col space-y-4">
          <a href="#services" className="text-gray-800 hover:text-motech-purple font-medium py-2">
            Services
          </a>
          <a href="#work" className="text-gray-800 hover:text-motech-purple font-medium py-2">
            Our Work
          </a>
          <a href="#about" className="text-gray-800 hover:text-motech-purple font-medium py-2">
            About
          </a>
          <a href="#testimonials" className="text-gray-800 hover:text-motech-purple font-medium py-2">
            Testimonials
          </a>
          <Button className="bg-motech-purple hover:bg-motech-dark-purple text-white w-full">
            Contact Us
          </Button>
        </div>
      </div>
    </header>
  );
};

export default Header;
