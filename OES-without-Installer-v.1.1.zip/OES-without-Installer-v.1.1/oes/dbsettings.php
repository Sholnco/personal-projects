
<?php

/*
***************************************************
*** Online Examination System                   ***
***---------------------------------------------***
*** License: GNU General Public License V.3     ***
*** Author: Manjunath Baddi                     ***
*** Title: Database Settings                    ***
***************************************************
*/

//This is the name of your server where the MySQL database is running
$dbserver="localhost";

//username of the MySQL server
$dbusername="root";

//password

$dbpassword="";

//database name of the online Examination system
$dbname="oes";

?>
